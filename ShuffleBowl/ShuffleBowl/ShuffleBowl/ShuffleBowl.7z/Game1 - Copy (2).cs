using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;

using FarseerPhysics.Dynamics;
using FarseerPhysics.Factories;
using FarseerPhysics.Common;
using FarseerPhysics.Collision.Shapes;
using Microsoft.Devices.Sensors;
using FarseerPhysics.Dynamics.Contacts;
using System.IO;
using System.IO.IsolatedStorage;

namespace FarseerPhysicsTutorial
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Sprite puck1;
        Sprite puck2;
        Sprite puck3;
        Sprite puck4;
        Sprite pin1;
        Sprite pin2;
        Sprite pin3;
        Sprite pin4;
        Sprite pin5;
        Sprite pin6;
        Sprite pin7;
        Sprite pin8;
        Sprite pin9;
        Sprite pin10;

        World world;
        Body boundary;
        Body playerBody;
        HighScoreData hs;
        Viewport viewport;

        float max, min;
        HUD hud;

        Vector2 curPos;
        Vector2 lastPos;
        Texture2D background;
        Texture2D ErrorLine;
        bool curSwipe = false;
        bool inMotion = false;
        bool waitingForName = false;
        TouchLocationState isPressed = TouchLocationState.Released;
        int turn = 0;
        float lastXCollision = 0;
        int scoreInc = 0;
        float redLine;
        static char[] newName;

        bool gameStarted = false;

        public Game1()
        {
            newName = new char[3];
            max = 0;
            min = 0;
            graphics = new GraphicsDeviceManager(this);
            graphics.SupportedOrientations = DisplayOrientation.Portrait;
            graphics.PreferredBackBufferWidth = 480;
            graphics.PreferredBackBufferHeight = 800;
            graphics.IsFullScreen = true;
            lastPos.X = -1;
            lastPos.Y = -1;
            redLine = 0;
            hs = new HighScoreData(5);
            Content.RootDirectory = "Content";

            // Frame rate is 30 fps by default for Windows Phone.
            TargetElapsedTime = TimeSpan.FromTicks(333333);

            // Extend battery life under lock.
            InactiveSleepTime = TimeSpan.FromSeconds(1);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            using (IsolatedStorageFile savegameStorage = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (savegameStorage.FileExists(HighScoresFilename))
                {
                    using (IsolatedStorageFileStream fs = savegameStorage.OpenFile(HighScoresFilename, System.IO.FileMode.Open))
                    {
                        if (fs != null)
                        {
                            hs = LoadHighScores(fs, hs.Count);
                        }
                    }
                }
            }
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            viewport = this.GraphicsDevice.Viewport;
            
            Texture2D playerTexture = Content.Load<Texture2D>("puck");
            background = Content.Load<Texture2D>("BowlingLane");
            ErrorLine = Content.Load<Texture2D>("RedLine");

            //boundries
            world = new World(Vector2.Zero);
            var bounds = GetBounds();
            boundary = BodyFactory.CreateLoopShape(world, bounds);
            boundary.CollisionCategories = Category.All;
            boundary.CollidesWith = Category.All;
            boundary.Friction = 0f;
            boundary.Restitution = 1f;
            boundary.BodyType = BodyType.Static;
            boundary.UserData = "BORDER";

            Vector2 initPin = new Vector2(ConvertUnits.ToSimUnits(viewport.Width / 2f), ConvertUnits.ToSimUnits(viewport.Height * .8f));
            redLine = ConvertUnits.ToSimUnits(viewport.Height * .75f);
            puck1 = new Sprite(playerTexture, initPin, world, "PUCK");
            puck2 = new Sprite(playerTexture, initPin, world, "PUCK");
            puck3 = new Sprite(playerTexture, initPin, world, "PUCK");
            puck4 = new Sprite(playerTexture, initPin, world, "PUCK");
//            puck1.body.Mass = .6f;
            puck1.body.OnCollision += body_OnCollision;
//            puck2.body.Mass = .6f;
            puck2.body.OnCollision += body_OnCollision;
//            puck3.body.Mass = .6f;
            puck3.body.OnCollision += body_OnCollision;
//            puck4.body.Mass = .6f;
            puck4.body.OnCollision += body_OnCollision;

            //disable pucks 2-4
            puck2.body.CollidesWith = Category.None;
            puck3.body.CollidesWith = Category.None;
            puck4.body.CollidesWith = Category.None;
            playerBody = puck1.body;
            playerBody.CollidesWith = Category.None;
      
            //init the pins
            playerTexture = Content.Load<Texture2D>("pin");
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.280f);
            initPin.Y = ConvertUnits.ToSimUnits(viewport.Height * 0.25f);
            pin1 = new Sprite(playerTexture, initPin, world, "PIN");
            pin1.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.427f);
            pin2 = new Sprite(playerTexture, initPin, world, "PIN");
            pin2.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.573f);
            pin3 = new Sprite(playerTexture, initPin, world, "PIN");
            pin3.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.720f);
            pin4 = new Sprite(playerTexture, initPin, world, "PIN");
            pin4.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.354f);
            initPin.Y = ConvertUnits.ToSimUnits(viewport.Height * 0.326f);
            pin5 = new Sprite(playerTexture, initPin, world, "PIN");
            pin5.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.5f);
            pin6 = new Sprite(playerTexture, initPin, world, "PIN");
            pin6.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.646f);
            pin7 = new Sprite(playerTexture, initPin, world, "PIN");
            pin7.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.427f);
            initPin.Y = ConvertUnits.ToSimUnits(viewport.Height * 0.405f);
            pin8 = new Sprite(playerTexture, initPin, world, "PIN");
            pin8.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.573f);
            pin9 = new Sprite(playerTexture, initPin, world, "PIN");
            pin9.body.OnCollision += body_OnCollision;
            initPin.X = ConvertUnits.ToSimUnits(viewport.Width * 0.5f);
            initPin.Y = ConvertUnits.ToSimUnits(viewport.Height * 0.481f);
            pin10 = new Sprite(playerTexture, initPin, world, "PIN");
            pin10.body.OnCollision += body_OnCollision;

            hud = new HUD();
            hud.Font = Content.Load<SpriteFont>("Arial");
        }

        bool body_OnCollision(Fixture fixtureA, Fixture fixtureB, Contact contact)
        {
            if (fixtureA.Body.UserData == "PUCK" && fixtureB.Body.UserData == "PUCK")
            {
                if (fixtureB.Body.Position.X != lastXCollision)
                {
                    hud.Score += 2400;
                    hud.add(fixtureA.Body.Position, 2400, Color.Gold);
                }
                lastXCollision = fixtureA.Body.Position.X;
            }
            else if (fixtureA.Body.UserData == "BORDER" || fixtureB.Body.UserData == "BORDER")
            {

            }
            else
            {
                if (fixtureB.Body.Position.X != lastXCollision)
                {
                    if (scoreInc < 240)
                        scoreInc += 10;
                    hud.Score += scoreInc;
                    hud.add(fixtureA.Body.Position, scoreInc, Color.White);
                }
                lastXCollision = fixtureA.Body.Position.X;

            }
            return true;
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// Provides a snapshot of timing values.
        protected override void Update(GameTime gameTime)
        {
            TouchCollection touchCollection = TouchPanel.GetState();
            if (gameStarted)
            {
                foreach (TouchLocation tl in touchCollection)
                {
                    isPressed = tl.State;
                    if ((isPressed == TouchLocationState.Pressed)
                            || (isPressed == TouchLocationState.Moved))
                    {
                        if (lastPos.X == -1)
                        {
                            lastPos.X = tl.Position.X;
                            lastPos.Y = tl.Position.Y;
                            //lastPos = ConvertUnits.ToSimUnits(lastPos);
                        }
                        else
                        {
                            lastPos = curPos;
                        }
                        curPos.X = tl.Position.X;
                        curPos.Y =  tl.Position.Y;
                        curPos = ConvertUnits.ToSimUnits(curPos);

                    }
                    if ((curSwipe || curPos.Y >= redLine) && !inMotion)
                    {

                        playerBody.Position = curPos;
                        if (curPos.Y < redLine)
                        {
                            inMotion = true;
                            isPressed = TouchLocationState.Released;
                        }
                        curSwipe = true;
                    }
                    if ((isPressed == TouchLocationState.Released && curSwipe))
                    {
                        if (curPos != lastPos)
                        {
                            playerBody.CollidesWith = Category.All;
                            inMotion = true;
                            curPos = (curPos - lastPos) * 10;
                            if(curPos.X < 0)
                                curPos.X = Math.Max(curPos.X, -25);
                            else
                                curPos.X = Math.Min(curPos.X, 25);
                            if (curPos.Y < 0)
                                curPos.Y = Math.Max(curPos.Y, -25);
                            else
                                curPos.Y = Math.Min(curPos.Y, 25);
                            playerBody.LinearVelocity = curPos;
                            //reset curpos
                            max = playerBody.LinearVelocity.X;
                            min = playerBody.LinearVelocity.Y;
                            curPos = Vector2.Zero;
                        }
                        curSwipe = false;
                    }
                    break; //ignore all other touches
                }

                if (inMotion)
                {
                    if (isStopped())
                    {
                        scoreInc = 0;
                        turn++;
                        switch (turn)
                        {
                            case (4):
                                using (IsolatedStorageFile savegameStorage = IsolatedStorageFile.GetUserStoreForApplication())
                                {
                                    IsolatedStorageFileStream fs = null;
                                    using (fs = savegameStorage.CreateFile(HighScoresFilename))
                                    {
                                        if (fs != null)
                                        {
                                            char[] temp = new char[3];
                                            checkIfHighScore(hs, fs, hud.Score);
                                            gameStarted = false;
                                        }
                                    }
                                }
                                break;
                            case (3):
                                puck4.body.CollidesWith = Category.All;
                                playerBody = puck4.body;
                                break;
                            case (2):
                                puck3.body.CollidesWith = Category.All;
                                playerBody = puck3.body;
                                break;
                            case (1):
                                puck2.body.CollidesWith = Category.All;
                                playerBody = puck2.body;
                                break;
                            default:
                                playerBody = puck1.body;
                                break;
                        }
                        playerBody.CollidesWith = Category.None;
                    }
                }
            }
            else
            {
                foreach (TouchLocation tl in touchCollection)
                {
                    if (tl.State == TouchLocationState.Pressed)
                        curSwipe = true;
                    if (tl.State == TouchLocationState.Released && curSwipe)
                    {
                        curSwipe = false;
                        gameStarted = true;
                    }
                }
            }
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            world.Step(Math.Min((float)gameTime.ElapsedGameTime.TotalSeconds, (1f / 30f)));
            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// Provides a snapshot of timing values.
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            spriteBatch.Draw(background, Vector2.Zero, Color.White);
            Vector2 rLine = new Vector2(0,ConvertUnits.ToDisplayUnits(redLine));
            spriteBatch.Draw(ErrorLine, rLine, Color.White);
            if (gameStarted)
            {
                switch (turn)
                {
                    case (3):
                        puck4.body = playerBody;
                        Sprite.Draw(spriteBatch, puck1, puck1.body.Position, 0f);
                        Sprite.Draw(spriteBatch, puck2, puck2.body.Position, 0f);
                        Sprite.Draw(spriteBatch, puck3, puck3.body.Position, 0f);
                        Sprite.Draw(spriteBatch, puck4, puck4.body.Position, 0f);
                        break;
                    case (2):
                        puck3.body = playerBody;
                        Sprite.Draw(spriteBatch, puck1, puck1.body.Position, 0f);
                        Sprite.Draw(spriteBatch, puck2, puck2.body.Position, 0f);
                        Sprite.Draw(spriteBatch, puck3, puck3.body.Position, 0f);
                        break;
                    case (1):
                        puck2.body = playerBody;
                        Sprite.Draw(spriteBatch, puck1, puck1.body.Position, 0f);
                        Sprite.Draw(spriteBatch, puck2, puck2.body.Position, 0f);
                        break;
                    default:
                        puck1.body = playerBody;
                        Sprite.Draw(spriteBatch, puck1, puck1.body.Position, 0f);
                        break;
                }

                Sprite.Draw(spriteBatch, pin1, pin1.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin2, pin2.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin3, pin3.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin4, pin4.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin5, pin5.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin6, pin6.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin7, pin7.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin8, pin8.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin9, pin9.body.Position, 0f);
                Sprite.Draw(spriteBatch, pin10, pin10.body.Position, 0f);
                hud.Draw(spriteBatch);
   /*             spriteBatch.DrawString(
                   Content.Load<SpriteFont>("Arial"),                          // SpriteFont
                    max.ToString(),  // Text
                    new Vector2(150, 600),                      // Position
                    Color.White);                  // Tint
                spriteBatch.DrawString(
                   Content.Load<SpriteFont>("Arial"),                          // SpriteFont
                    min.ToString(),  // Text
                    new Vector2(250, 600),                      // Position
                    Color.White);                  // Tint
    */
            }
            else
            {
                hs.Draw(spriteBatch, viewport, hs, Content.Load<SpriteFont>("Arial"));
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }

        private Vertices GetBounds()
        {
            float width = ConvertUnits.ToSimUnits(this.GraphicsDevice.Viewport.Width);
            float height = ConvertUnits.ToSimUnits(this.GraphicsDevice.Viewport.Height);

            Vertices bounds = new Vertices(4);
            bounds.Add(new Vector2(0, 0));
            bounds.Add(new Vector2(width, 0));
            bounds.Add(new Vector2(width, height));
            bounds.Add(new Vector2(0, height));

            return bounds;
        }
        private bool isStopped()
        {
            if (Math.Abs(puck1.body.LinearVelocity.X) > .01 && Math.Abs(puck1.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(puck2.body.LinearVelocity.X) > .01 && Math.Abs(puck2.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(puck3.body.LinearVelocity.X) > .01 && Math.Abs(puck3.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(puck4.body.LinearVelocity.X) > .01 && Math.Abs(puck4.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin1.body.LinearVelocity.X) > .01 && Math.Abs(pin1.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin2.body.LinearVelocity.X) > .01 && Math.Abs(pin2.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin3.body.LinearVelocity.X) > .01 && Math.Abs(pin3.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin4.body.LinearVelocity.X) > .01 && Math.Abs(pin4.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin5.body.LinearVelocity.X) > .01 && Math.Abs(pin5.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin6.body.LinearVelocity.X) > .01 && Math.Abs(pin6.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin7.body.LinearVelocity.X) > .01 && Math.Abs(pin7.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin8.body.LinearVelocity.X) > .01 && Math.Abs(pin8.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin9.body.LinearVelocity.X) > .01 && Math.Abs(pin9.body.LinearVelocity.Y) > .01)
                return false;
            if (Math.Abs(pin10.body.LinearVelocity.X) > .01 && Math.Abs(pin10.body.LinearVelocity.Y) > .01)
                return false;
            puck1.body.LinearVelocity = Vector2.Zero;
            puck2.body.LinearVelocity = Vector2.Zero;
            puck3.body.LinearVelocity = Vector2.Zero;
            puck4.body.LinearVelocity = Vector2.Zero;
            pin1.body.LinearVelocity = Vector2.Zero;
            pin2.body.LinearVelocity = Vector2.Zero;
            pin3.body.LinearVelocity = Vector2.Zero;
            pin4.body.LinearVelocity = Vector2.Zero;
            pin5.body.LinearVelocity = Vector2.Zero;
            pin6.body.LinearVelocity = Vector2.Zero;
            pin7.body.LinearVelocity = Vector2.Zero;
            pin8.body.LinearVelocity = Vector2.Zero;
            pin9.body.LinearVelocity = Vector2.Zero;
            pin10.body.LinearVelocity = Vector2.Zero;

            inMotion = false;
            return true;
        }


        public readonly string HighScoresFilename = "shufflebowlhs.lst";


        public static void SaveHighScores(HighScoreData data, IsolatedStorageFileStream fs, int newScore)
        {
            int y = 0;
            bool overWrite = true;
            for (int x = 0; x < data.Count; x++)
            {
                byte[] bits = new byte[3];
                if (newScore > data.Score[x] && overWrite)
                {
                    bits[0] = (Byte)(newName[0]);
                    bits[1] = (Byte)(newName[1]);
                    bits[2] = (Byte)(newName[2]);
                    fs.Write(bits, 0, bits.Length);
                    bits = System.BitConverter.GetBytes(newScore);
                    fs.Write(bits, 0, bits.Length);
                    overWrite = false;
                }
                else
                {
                    bits[0] = (Byte)(data.PlayerName[y][0]);
                    bits[1] = (Byte)(data.PlayerName[y][1]);
                    bits[2] = (Byte)(data.PlayerName[y][2]);
                    fs.Write(bits, 0, bits.Length);
                    bits = System.BitConverter.GetBytes(data.Score[y]);
                    fs.Write(bits, 0, bits.Length);
                    y++;
                }
            }
        }
        public static void checkIfHighScore(HighScoreData data, IsolatedStorageFileStream fs, int newScore)
        {
            for (int x = 0; x < data.Count; x++)
            {
                if (newScore > data.Score[x])
                {
                    Guide.BeginShowKeyboardInput(
                       PlayerIndex.One,
                       "You Have a New High Score!",
                       "Enter your initials:",
                       "",
                       new AsyncCallback(OnEndShowKeyboardInput),
                       null);
                    while () ;
                    //TODO BETTER WAY OF DOING THIS
                    SaveHighScores(data, fs, newScore);
                    break;
                }
            }
        }
        static private void OnEndShowKeyboardInput(IAsyncResult result)
        {
            char[] temp = new char[2];
            int initialCount = 0;
            temp = Guide.EndShowKeyboardInput(result).ToCharArray();
            for (initialCount = 0; initialCount < temp.Length; initialCount++)
            {
                try
                {
                    newName[initialCount] = temp[initialCount];
                }
                catch (IndexOutOfRangeException)
                {
                    newName[initialCount] = '.';
                }
            }
        }
        public static HighScoreData LoadHighScores(IsolatedStorageFileStream fs, int count)
        {
            HighScoreData data = new HighScoreData(count);
            char[] tempName = new char[3];
            for (int x = 0; x < count; x++)
            {
                // Reload the saved high-score data.
                byte[] saveBytes = new byte[3];
                fs.Read(saveBytes, 0, saveBytes.Length);
                tempName[0] = (char)saveBytes[0];
                tempName[1] = (char)saveBytes[1];
                tempName[2] = (char)saveBytes[2];
                tempName.CopyTo(data.PlayerName[x],0);
                //data.PlayerName[x] = System.BitConverter.ToString(saveBytes);
                saveBytes = new byte[4];
                fs.Read(saveBytes, 0, saveBytes.Length);
                data.Score[x] = System.BitConverter.ToInt32(saveBytes, 0);
            }
            return (data);
        }
    }
}
